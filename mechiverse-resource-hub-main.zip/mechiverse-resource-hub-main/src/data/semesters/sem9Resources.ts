
import { ResourceProps } from "@/components/ResourceCard";

const sem9Resources: ResourceProps[] = [
  // You can add Sem 9 subjects here in future
];

export default sem9Resources;
