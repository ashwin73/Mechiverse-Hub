
import { ResourceProps } from "@/components/ResourceCard";

const sem7Resources: ResourceProps[] = [
  // You can add Sem 7 subjects here in future
];

export default sem7Resources;
