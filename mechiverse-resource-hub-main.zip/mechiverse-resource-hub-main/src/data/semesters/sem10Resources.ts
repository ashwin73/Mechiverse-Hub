
import { ResourceProps } from "@/components/ResourceCard";

const sem10Resources: ResourceProps[] = [
  // You can add Sem 10 subjects here in future
];

export default sem10Resources;
