
import { ResourceProps } from "@/components/ResourceCard";

const sem8Resources: ResourceProps[] = [
  // You can add Sem 8 subjects here in future
];

export default sem8Resources;
